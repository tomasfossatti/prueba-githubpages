import Link from "next/link"
import { Github, Linkedin, Instagram, Youtube } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-900">
      {/* Header/Navigation */}
      <header className="border-b border-gray-800">
        <div className="container mx-auto py-4 px-4 flex justify-between items-center">
          <span className="text-xl font-bold text-white"></span>
          <nav className="hidden md:flex space-x-6">
            <Link href="#social" className="text-gray-300 hover:text-blue-400 transition-colors">
              Redes
            </Link>
            <Link href="#blog" className="text-gray-300 hover:text-blue-400 transition-colors">
              Blog
            </Link>
            <Link href="#research" className="text-gray-300 hover:text-blue-400 transition-colors">
              Investigaciones
            </Link>
            <Link href="#volunteering" className="text-gray-300 hover:text-blue-400 transition-colors">
              Voluntariado
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="py-20 md:py-32 bg-gray-900">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-4 text-white">Tomás Fossatti</h1>
            <h2 className="text-xl md:text-2xl text-gray-400 mb-6">
              Innovación y Desarrollo | Inteligencia Artificial
            </h2>
            <p className="max-w-2xl mx-auto text-lg mb-8 text-gray-300">
              Acá vas a encontrar mis proyectos e investigaciones.
            </p>
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white">
              Explorá mis proyectos
            </Button>
          </div>
        </section>

        {/* Social Media Section */}
        <section id="social" className="py-16 bg-gray-800 w-full">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-4 text-white">Conéctate conmigo</h2>
            <p className="text-center text-gray-400 mb-10 max-w-2xl mx-auto">
              Descubrí mis perfiles en redes sociales y mis proyectos más recientes.
            </p>
            <div className="w-full grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-4xl mx-auto">
              <SocialButton
                href="https://github.com/tomasfossatti"
                icon={<Github className="h-5 w-5" />}
                label="GitHub"
                className="bg-gray-700 hover:bg-gray-600 border-gray-600"
                iconClass="text-gray-300 group-hover:text-white"
              />
              <SocialButton
                href="https://www.linkedin.com/in/tomas-fossatti-ing/"
                icon={<Linkedin className="h-5 w-5" />}
                label="LinkedIn"
                className="bg-gray-700 hover:bg-blue-900 border-gray-600"
                iconClass="text-gray-300 group-hover:text-blue-300"
              />
              <SocialButton
                href="https://www.instagram.com/tomasfossatti_/"
                icon={<Instagram className="h-5 w-5" />}
                label="Instagram"
                className="bg-gray-700 hover:bg-pink-900 border-gray-600"
                iconClass="text-gray-300 group-hover:text-pink-300"
              />
              <SocialButton
                href="https://www.youtube.com/@tempiax"
                icon={<Youtube className="h-5 w-5" />}
                label="YouTube"
                className="bg-gray-700 hover:bg-red-900 border-gray-600"
                iconClass="text-gray-300 group-hover:text-red-300"
              />
            </div>
          </div>
        </section>

        {/* Blog Section */}
        <section id="blog" className="py-16 bg-gray-900">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-4 text-white">Mi Blog</h2>
            <p className="text-center text-gray-400 mb-6 max-w-2xl mx-auto">
              Artículos sobre Inteligencia Artificial, Machine Learning, tecnología y más. Mis reflexiones y
              aprendizajes.
            </p>
            <p className="text-center italic max-w-2xl mx-auto text-gray-400">
              Próximamente, estaré publicando contenido sobre IA y mis investigaciones.
            </p>

            {/* Placeholder for future blog posts */}
            <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
              <BlogPostCard title="Próximamente" excerpt="Artículos sobre IA y Machine Learning" date="2025" />
              <BlogPostCard title="Próximamente" excerpt="Tutoriales y guías prácticas" date="2025" />
              <BlogPostCard title="Próximamente" excerpt="Reflexiones sobre tecnología" date="2025" />
            </div>
          </div>
        </section>

        {/* Research Section */}
        <section id="research" className="py-16 bg-gray-800">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-4 text-white">Investigaciones</h2>
            <p className="text-center text-gray-400 mb-6 max-w-2xl mx-auto">
              Proyectos de investigación en IA y Machine Learning. Mis contribuciones y descubrimientos en el campo.
            </p>
            <p className="text-center italic max-w-2xl mx-auto text-gray-400">
              Esta sección se actualizará pronto con detalles sobre mis investigaciones actuales.
            </p>

            {/* Placeholder for future research projects */}
            <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              <ResearchCard
                title="Inteligencia Artificial"
                description="Investigaciones en el campo de la IA y sus aplicaciones prácticas."
              />
              <ResearchCard
                title="Machine Learning"
                description="Exploración de algoritmos y modelos de aprendizaje automático."
              />
            </div>
          </div>
        </section>

        {/* Volunteering Section */}
        <section id="volunteering" className="py-16 bg-gray-900">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-4 text-white">Voluntariado</h2>

            <div className="mt-12 max-w-4xl mx-auto bg-gray-800 rounded-lg border border-gray-700 overflow-hidden">
              <div className="p-6 md:p-8">
                <h3 className="text-2xl font-bold text-white mb-1">Museo de Informática</h3>
                <p className="text-blue-400 mb-6">
                  Proyecto enfocado en la investigación de tecnología histórica y desarrollo de emuladores
                </p>

                <div className="mb-8">
                  <p className="text-gray-300 mb-4">
                    Colaboro con el{" "}
                    <a
                      href="https://espaciotec.com.ar/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-400 hover:underline"
                    >
                      Museo de Informática
                    </a>{" "}
                    en el desarrollo de software interactivo para mainframes antiguos, investigación de hardware
                    histórico y creación de contenido educativo.
                  </p>
                </div>

                <div className="mb-8">
                  <h4 className="text-xl font-semibold text-white mb-3">Proyectos destacados</h4>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-gray-700 p-5 rounded-lg border border-gray-600">
                      <h5 className="text-lg font-medium text-white mb-2">Emulación de IBM 3270</h5>
                      <p className="text-gray-300">
                        Desarrollo de aplicaciones que simulan el uso original del sistema, pensadas para ser usadas por
                        el público del museo.
                      </p>
                    </div>

                    <div className="bg-gray-700 p-5 rounded-lg border border-gray-600">
                      <h5 className="text-lg font-medium text-white mb-2">
                        Investigación sobre la computadora argentina 20c
                      </h5>
                      <p className="text-gray-300">
                        Recolección de documentación técnica e histórica, diseño de filminas para mostrar en el museo
                        junto a la máquina.
                      </p>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-xl font-semibold text-white mb-3">Tecnologías utilizadas</h4>
                  <div className="flex flex-wrap gap-3">
                      <TechBadge>HTML/CSS</TechBadge>
                    <TechBadge>Emuladores</TechBadge>
                    <TechBadge>Documentación técnica</TechBadge>
                    <TechBadge>Investigación histórica</TechBadge>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="py-10 border-t border-gray-800 bg-gray-900">
        <div className="container mx-auto px-4">
          <p className="text-center mb-6 text-gray-300">
            Gracias por visitar mi página. Si deseas colaborar, aprender o compartir ideas, ¡no dudes en contactarme!
          </p>

          <div className="flex justify-center space-x-6 mb-8">
            <Link href="https://github.com/tomasfossatti" className="text-gray-400 hover:text-white transition-colors">
              <Github className="h-6 w-6" />
              <span className="sr-only">GitHub</span>
            </Link>
            <Link
              href="https://www.linkedin.com/in/tomasfossatti/"
              className="text-gray-400 hover:text-blue-300 transition-colors"
            >
              <Linkedin className="h-6 w-6" />
              <span className="sr-only">LinkedIn</span>
            </Link>
            <Link
              href="https://www.instagram.com/tomasfossatti_/"
              className="text-gray-400 hover:text-pink-300 transition-colors"
            >
              <Instagram className="h-6 w-6" />
              <span className="sr-only">Instagram</span>
            </Link>
            <Link
              href="https://www.youtube.com/@tempiax"
              className="text-gray-400 hover:text-red-300 transition-colors"
            >
              <Youtube className="h-6 w-6" />
              <span className="sr-only">YouTube</span>
            </Link>
          </div>

          <p className="text-center text-sm text-gray-500">
            © {new Date().getFullYear()} Tomás Fossatti. Todos los derechos reservados.
          </p>
        </div>
      </footer>
    </div>
  )
}

// Component for social media buttons
function SocialButton({ href, icon, label, className = "", iconClass = "" }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className={`group flex items-center justify-center p-4 border rounded-lg transition-all duration-200 w-full ${className}`}
    >
      <div className={`transition-colors duration-200 ${iconClass}`}>{icon}</div>
      <span className="font-medium ml-2 text-gray-300 group-hover:text-white transition-colors duration-200">
        {label}
      </span>
    </a>
  )
}

// Component for blog post cards
function BlogPostCard({ title, excerpt, date }) {
  return (
    <div className="border border-gray-700 rounded-lg p-6 hover:bg-gray-800 transition-colors bg-gray-800">
      <h3 className="font-bold text-xl mb-2 text-white">{title}</h3>
      <p className="text-gray-400 mb-4">{excerpt}</p>
      <p className="text-sm text-gray-500">{date}</p>
    </div>
  )
}

// Component for research cards
function ResearchCard({ title, description }) {
  return (
    <div className="border border-gray-700 rounded-lg p-6 hover:bg-gray-700 transition-colors bg-gray-700">
      <h3 className="font-bold text-xl mb-3 text-white">{title}</h3>
      <p className="text-gray-300">{description}</p>
    </div>
  )
}

// Component for tech badges
function TechBadge({ children }) {
  return (
    <span className="inline-block bg-gray-700 text-gray-300 px-3 py-1 rounded-full text-sm border border-gray-600">
      {children}
    </span>
  )
}
